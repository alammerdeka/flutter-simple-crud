import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:starter/model/response_barang_model.dart';
import 'package:starter/model/response_post_model.dart';

class ApiService {

}
